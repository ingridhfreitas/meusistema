package br.com.meusistema.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeuSistemaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeuSistemaApplication.class, args);
	}

}
